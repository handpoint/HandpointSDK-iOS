var searchData=
[
  ['cancel',['cancel',['../group___h_c___d_e_l_e_g_a_t_e.html#ga75599313094c53ae516c8a0a61e45600',1,'HeftClient-p']]],
  ['cancelsignature',['cancelSignature',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html#gabd799ac41835999c4194cffc3446c916',1,'HeftStatusReportDelegate-p']]],
  ['clientfordevice_3asharedsecret_3adelegate_3a',['clientForDevice:sharedSecret:delegate:',['../interface_heft_manager.html#a764143c55b9de397077328b6c46c9e2b',1,'HeftManager']]]
];
