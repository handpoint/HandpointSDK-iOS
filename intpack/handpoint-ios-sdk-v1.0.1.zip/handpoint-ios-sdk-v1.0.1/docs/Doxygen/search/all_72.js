var searchData=
[
  ['refundvoidwithamount_3acurrency_3acardholder_3atransaction_3a',['refundVoidWithAmount:currency:cardholder:transaction:',['../group___h_c___d_e_l_e_g_a_t_e.html#ga26d1185a07a0abb7fe4243dff5773e20',1,'HeftClient-p']]],
  ['refundwithamount_3acurrency_3acardholder_3a',['refundWithAmount:currency:cardholder:',['../group___h_c___d_e_l_e_g_a_t_e.html#ga0f13a1d8babd53ff50c576bb693c765f',1,'HeftClient-p']]],
  ['requestsignature_3a',['requestSignature:',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html#ga883847fc411a7e055a37fa63980def19',1,'HeftStatusReportDelegate-p']]],
  ['resetdevices',['resetDevices',['../group___h_f_d___p_r_o_t_o_c_o_l.html#ga3ef0fb29d8022e9fef210dfb109aa7bb',1,'HeftDiscovery-p']]],
  ['responseerror_3a',['responseError:',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html#ga186eb576ba2ec69f9d178f9cdafe0232',1,'HeftStatusReportDelegate-p']]],
  ['responsefinancestatus_3a',['responseFinanceStatus:',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html#ga37a9cc58b18c3af91ba52238bb280e7b',1,'HeftStatusReportDelegate-p']]],
  ['responseinfo_2dp',['ResponseInfo-p',['../protocol_response_info-p.html',1,'']]],
  ['responseloginfo_3a',['responseLogInfo:',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html#ga983b9ea41b6df2c3f81dfa98c1f1f686',1,'HeftStatusReportDelegate-p']]],
  ['responsestatus_3a',['responseStatus:',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html#gac0dd07e49bd1cf95ee1e4249e275c090',1,'HeftStatusReportDelegate-p']]],
  ['responseinfo_20protocol',['ResponseInfo Protocol',['../group___r_i___p_r_o_t_o_c_o_l.html',1,'']]]
];
