var searchData=
[
  ['transactionid',['transactionId',['../group___f_r_i___p_r_o_t_o_c_o_l.html#ga953b3cf321dfd8f769c1d9ac19b434c3',1,'FinanceResponseInfo-p']]]
];
