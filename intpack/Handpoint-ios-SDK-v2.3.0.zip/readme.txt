Handpoint iOS SDK v.2.3.0

This package contains the Handpoint iOS SDK version 2.3.0

 - The folder HeftLibrary contains the library to be used with an actual card reader.

More information about the library and documentation can be found here: https://www.handpoint.com/docs/device/iOS/