var searchData=
[
  ['nosources',['noSources',['../group___h_d_d___p_r_o_t_o_c_o_l.html#ga76dee9b433104fe4020cc97fda74110f',1,'HeftDiscoveryDelegate-p']]]
];
