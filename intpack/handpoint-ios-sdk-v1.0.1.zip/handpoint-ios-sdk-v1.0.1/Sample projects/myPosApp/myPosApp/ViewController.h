//
//  ViewController.h
//  myPosApp
//
//  Created by Olafur Oskar Egilsson on 5/10/13.
//  Copyright (c) 2013 handpoint. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeftClient.h"
#import "HeftManager.h"
#import "HeftStatusReportPublic.h"


@interface ViewController : UIViewController <HeftDiscoveryDelegate, HeftStatusReportDelegate> {

}

@property(nonatomic, strong) id<HeftClient> heftClient;

@end
