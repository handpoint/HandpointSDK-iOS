var searchData=
[
  ['delegate',['delegate',['../group___h_f_d___p_r_o_t_o_c_o_l.html#ga7e6f87b0fca9611f50699ab4626ceb63',1,'HeftDiscovery-p']]],
  ['devices',['devices',['../group___h_f_d___p_r_o_t_o_c_o_l.html#ga8cf2b52b578aba5451d9e1e5e683d6e1',1,'HeftDiscovery-p']]],
  ['didconnect_3a',['didConnect:',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html#ga6a988f7d1b2e9271c7f347ce63590662',1,'HeftStatusReportDelegate-p']]],
  ['diddiscoverdevice_3a',['didDiscoverDevice:',['../group___h_d_d___p_r_o_t_o_c_o_l.html#gafa29804232c126e17f461d277af059ec',1,'HeftDiscoveryDelegate-p']]],
  ['diddiscoverfinished',['didDiscoverFinished',['../group___h_d_d___p_r_o_t_o_c_o_l.html#gade54ef846feab19ad3016600f8c2ed99',1,'HeftDiscoveryDelegate-p']]]
];
