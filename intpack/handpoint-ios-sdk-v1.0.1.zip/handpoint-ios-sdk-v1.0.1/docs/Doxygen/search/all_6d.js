var searchData=
[
  ['merchantreceipt',['merchantReceipt',['../group___f_r_i___p_r_o_t_o_c_o_l.html#gadb3b6d3a5eb92d74664d853b7129e3dc',1,'FinanceResponseInfo-p']]],
  ['mpedinfo',['mpedInfo',['../group___h_c___d_e_l_e_g_a_t_e.html#ga2e83149f04597919436ac1b2e85adeda',1,'HeftClient-p']]]
];
