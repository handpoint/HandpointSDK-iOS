//
//  ViewController.h
//  myPosApp
//
//  Created by Olafur Oskar Egilsson on 1/15/13.
//  Copyright (c) 2013 handpoint. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeftManager.h"
#import "HeftClient.h"
#import "HeftStatusReport.h"


@interface ViewController : UIViewController <HeftDiscoveryDelegate, HeftStatusReportDelegate>{
	id<HeftClient> heftClient;
}
- (IBAction)startSale;

@end
