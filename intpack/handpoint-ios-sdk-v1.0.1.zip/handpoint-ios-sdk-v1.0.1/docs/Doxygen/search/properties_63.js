var searchData=
[
  ['customerreceipt',['customerReceipt',['../group___f_r_i___p_r_o_t_o_c_o_l.html#gaf516891fa42208acd8b0bb8e9f7de367',1,'FinanceResponseInfo-p']]]
];
