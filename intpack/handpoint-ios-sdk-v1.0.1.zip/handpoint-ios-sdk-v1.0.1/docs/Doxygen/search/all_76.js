var searchData=
[
  ['version',['version',['../interface_heft_manager.html#a7f281ea05c73bb1f3be034c1bd0e818a',1,'HeftManager']]]
];
