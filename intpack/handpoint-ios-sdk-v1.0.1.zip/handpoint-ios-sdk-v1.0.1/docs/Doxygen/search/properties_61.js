var searchData=
[
  ['authorisedamount',['authorisedAmount',['../group___f_r_i___p_r_o_t_o_c_o_l.html#gaadaffe34214c89caa189a2e287351baf',1,'FinanceResponseInfo-p']]]
];
