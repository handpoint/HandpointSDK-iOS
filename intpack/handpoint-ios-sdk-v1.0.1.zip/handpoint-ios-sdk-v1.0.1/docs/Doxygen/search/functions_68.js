var searchData=
[
  ['hassources',['hasSources',['../group___h_d_d___p_r_o_t_o_c_o_l.html#gafc507ba538f414af8c1b53eeaae3333b',1,'HeftDiscoveryDelegate-p::hasSources()'],['../interface_heft_manager.html#a7d28d7b8cc44cdd9c22d1b5d266a4692',1,'HeftManager::hasSources()']]]
];
