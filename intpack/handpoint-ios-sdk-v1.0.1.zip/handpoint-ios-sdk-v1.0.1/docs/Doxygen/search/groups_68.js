var searchData=
[
  ['heftclient_20methods',['HeftClient Methods',['../group___h_c___d_e_l_e_g_a_t_e.html',1,'']]],
  ['heftdiscoverydelegate_20notifications',['HeftDiscoveryDelegate Notifications',['../group___h_d_d___p_r_o_t_o_c_o_l.html',1,'']]],
  ['heftdiscovery_20protocol',['HeftDiscovery Protocol',['../group___h_f_d___p_r_o_t_o_c_o_l.html',1,'']]],
  ['heftstatusreportdelegate_20notifications',['HeftStatusReportDelegate Notifications',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html',1,'']]]
];
