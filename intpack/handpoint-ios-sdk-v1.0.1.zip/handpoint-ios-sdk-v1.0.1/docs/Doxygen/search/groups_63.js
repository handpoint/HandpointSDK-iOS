var searchData=
[
  ['characteristics_20of_20the_20device',['Characteristics of the Device',['../group___c_d___m_o_d_u_l_e.html',1,'']]]
];
