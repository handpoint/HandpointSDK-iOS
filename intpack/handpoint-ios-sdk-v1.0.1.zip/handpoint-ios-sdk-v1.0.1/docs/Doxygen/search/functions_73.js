var searchData=
[
  ['salevoidwithamount_3acurrency_3acardholder_3atransaction_3a',['saleVoidWithAmount:currency:cardholder:transaction:',['../group___h_c___d_e_l_e_g_a_t_e.html#gad29cc6e9f89c97e1769ee7821b445399',1,'HeftClient-p']]],
  ['salewithamount_3acurrency_3acardholder_3a',['saleWithAmount:currency:cardholder:',['../group___h_c___d_e_l_e_g_a_t_e.html#ga530ea68135df404fcb19d758a2c0b8be',1,'HeftClient-p']]],
  ['sharedmanager',['sharedManager',['../interface_heft_manager.html#af96293c7c78b658c7a66e72be82ade89',1,'HeftManager']]],
  ['startdiscovery_3a',['startDiscovery:',['../group___h_f_d___p_r_o_t_o_c_o_l.html#gab8fe04732858da35885cf3638debc4e1',1,'HeftDiscovery-p']]]
];
