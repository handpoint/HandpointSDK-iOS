var searchData=
[
  ['acceptsignature_3a',['acceptSignature:',['../group___h_c___d_e_l_e_g_a_t_e.html#ga100466dab95b365d0b3d33606c6965b3',1,'HeftClient-p']]]
];
