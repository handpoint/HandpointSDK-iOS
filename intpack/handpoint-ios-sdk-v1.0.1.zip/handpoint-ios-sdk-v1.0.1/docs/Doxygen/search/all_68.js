var searchData=
[
  ['hassources',['hasSources',['../group___h_d_d___p_r_o_t_o_c_o_l.html#gafc507ba538f414af8c1b53eeaae3333b',1,'HeftDiscoveryDelegate-p::hasSources()'],['../interface_heft_manager.html#a7d28d7b8cc44cdd9c22d1b5d266a4692',1,'HeftManager::hasSources()']]],
  ['heftclient_20methods',['HeftClient Methods',['../group___h_c___d_e_l_e_g_a_t_e.html',1,'']]],
  ['heftdiscoverydelegate_20notifications',['HeftDiscoveryDelegate Notifications',['../group___h_d_d___p_r_o_t_o_c_o_l.html',1,'']]],
  ['heftclient_2dp',['HeftClient-p',['../protocol_heft_client-p.html',1,'']]],
  ['heftclient_2eh',['HeftClient.h',['../_heft_client_8h.html',1,'']]],
  ['heftdiscovery_2dp',['HeftDiscovery-p',['../protocol_heft_discovery-p.html',1,'']]],
  ['heftdiscoverydelegate_2dp',['HeftDiscoveryDelegate-p',['../protocol_heft_discovery_delegate-p.html',1,'']]],
  ['heftmanager',['HeftManager',['../interface_heft_manager.html',1,'']]],
  ['heftmanager_2eh',['HeftManager.h',['../_heft_manager_8h.html',1,'']]],
  ['heftstatusreportdelegate_2dp',['HeftStatusReportDelegate-p',['../protocol_heft_status_report_delegate-p.html',1,'']]],
  ['heftstatusreportpublic_2eh',['HeftStatusReportPublic.h',['../_heft_status_report_public_8h.html',1,'']]],
  ['heftdiscovery_20protocol',['HeftDiscovery Protocol',['../group___h_f_d___p_r_o_t_o_c_o_l.html',1,'']]],
  ['heftstatusreportdelegate_20notifications',['HeftStatusReportDelegate Notifications',['../group___h_s_r_d___p_r_o_t_o_c_o_l.html',1,'']]]
];
