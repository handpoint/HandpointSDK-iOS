Headstart iOS SDK Beta Version 1.0.1

== Release notes ==
This is a early beta release of Headstart for iOS, bugs and quirks are to be expected. Please report all bugs to Handpoint.

Supported functionality:

* Discovery of remote BT devices.
* Connect to remote BT device.
* Executing financial transaction.
* Reporting status of transactions.
* Control and access to device logs.
* Limited card reader simulation.

Includes detailed documentation and a sample project

Notable changes since version 1.0.1:
Includes doxygen generated documentation
heftClient is now received through didConnect delegate
heftStatusReport has been renamed to heftStatusReportPublic
Passed response objects are now handled as id values

Known Issues:
Only runs on physical iOS devices, does not work on iOS simulators.
== == == == == ==

**Confidentiality and Intellectual property right statement**

This document is a part of a software development kit (SDK) you have downloaded from the Handpoint website or you might have received from a third party by some other means. You, as the reader, are aware that all information, whatsoever, contained in this SDK is confidential (Confidential Information) and is the property of Handpoint or its licensors and as such protected by law. This document or any information it contains, whether text, numbers, tables, pictures, graphs or other, may not be disclosed, copied, reproduced or distributed to a third party in any way without the prior consent of Handpoint.

You may only use this SDK to help you connect to the Handpoint payment platform using our API (application programming interface). You may not directly or indirectly, in any way, reveal, report, publish, disclose, transfer or otherwise use or exploit any of the Confidential Information except as specifically authorised by Handpoint. Furthermore you may not reverse engineer any of the contents of the SDK or use any Confidential Information to compete with Handpoint or obtain advantage vis à vis in any commercial activity.

Misuse or unauthorized distribution of this document or the information it contains may result in Handpoint seeking legal measures before the district court of Reykjavik, Iceland.