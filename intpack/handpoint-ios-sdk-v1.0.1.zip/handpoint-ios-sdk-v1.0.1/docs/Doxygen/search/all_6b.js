var searchData=
[
  ['kappnameinfokey',['kAppNameInfoKey',['../group___c_d___m_o_d_u_l_e.html#ga4dc836ad6cb3707a1f21699ad7622e3c',1,'HeftClient.h']]],
  ['kappversioninfokey',['kAppVersionInfoKey',['../group___c_d___m_o_d_u_l_e.html#gae6c3172365a3bc02056a78770d5f8153',1,'HeftClient.h']]],
  ['kemvparamversioninfokey',['kEMVParamVersionInfoKey',['../group___c_d___m_o_d_u_l_e.html#ga3450f0fea869fca7138bfe9cf916d88e',1,'HeftClient.h']]],
  ['kgeneralparaminfokey',['kGeneralParamInfoKey',['../group___c_d___m_o_d_u_l_e.html#ga78ec9d4f47e005080c326b1d0b2ef364',1,'HeftClient.h']]],
  ['kmanufacturercodeinfokey',['kManufacturerCodeInfoKey',['../group___c_d___m_o_d_u_l_e.html#gaf727793119c59fe9511011fb6da04772',1,'HeftClient.h']]],
  ['kmodelcodeinfokey',['kModelCodeInfoKey',['../group___c_d___m_o_d_u_l_e.html#ga1be8469a5ff32a28508c8fe5af0fabc2',1,'HeftClient.h']]],
  ['kpublickeyversioninfokey',['kPublicKeyVersionInfoKey',['../group___c_d___m_o_d_u_l_e.html#gab08e517db1a7af5b0d3900ed89c71b15',1,'HeftClient.h']]],
  ['kserialnumberinfokey',['kSerialNumberInfoKey',['../group___c_d___m_o_d_u_l_e.html#gaf2847132d9db6350efb3a90b6dfca971',1,'HeftClient.h']]],
  ['kxmldetailsinfokey',['kXMLDetailsInfoKey',['../group___c_d___m_o_d_u_l_e.html#ga5981dafdc650ad1d28ea00280abb5489',1,'HeftClient.h']]]
];
