//
//  AppDelegate.h
//  myPosApp
//
//  Created by Olafur Oskar Egilsson on 1/15/13.
//  Copyright (c) 2013 handpoint. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
