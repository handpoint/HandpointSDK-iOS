var searchData=
[
  ['loggetinfo',['logGetInfo',['../group___h_c___d_e_l_e_g_a_t_e.html#ga1bccce630dad47a64a2ad503b9ff4b25',1,'HeftClient-p']]],
  ['logreset',['logReset',['../group___h_c___d_e_l_e_g_a_t_e.html#ga05ede14433c643d436073848c5a204f2',1,'HeftClient-p']]],
  ['logsetlevel_3a',['logSetLevel:',['../group___h_c___d_e_l_e_g_a_t_e.html#gadeee03241d1b1d0fc2b145abb5dff5e0',1,'HeftClient-p']]]
];
