var searchData=
[
  ['status',['status',['../group___r_i___p_r_o_t_o_c_o_l.html#ga7baee5ff78cab19295bdf01b5df2b963',1,'ResponseInfo-p']]],
  ['statuscode',['statusCode',['../group___r_i___p_r_o_t_o_c_o_l.html#ga696bc0fd03f91a5435bc8274ef9d299d',1,'ResponseInfo-p']]]
];
